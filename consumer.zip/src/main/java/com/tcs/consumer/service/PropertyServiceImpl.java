package com.tcs.consumer.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.consumer.entity.Property;
import com.tcs.consumer.repo.PropertyRepository;

@Service
public class PropertyServiceImpl implements PropertyService{

	@Autowired
	PropertyRepository propertyRepository;

	@Override
	public List<Property> getProperty() {
		// TODO Auto-generated method stub
		return propertyRepository.findAll();
	}

	@Override
	public Property getPropertyById(int id) {
		// TODO Auto-generated method stub
		return propertyRepository.findById(id).get();
	}

	@Override
	public void addProperty(Property property) {
		// TODO Auto-generated method stub
		propertyRepository.save(property);
	}

	@Override
	public void editPropertyr(int id, Property property) {
		// TODO Auto-generated method stub
		propertyRepository.save(property);
	}

	@Override
	public void deleteProperty(int id) {
		// TODO Auto-generated method stub
		propertyRepository.deleteById(id);
	}
	
	
	
}
