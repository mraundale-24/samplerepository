package com.tcs.consumer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.consumer.entity.Business;
import com.tcs.consumer.repo.BusinessRepository;

@Service
public class BusinessServiceImpl implements BusinessService {

	@Autowired
	BusinessRepository businessRepository;

	@Override
	public List<Business> getBusiness() {
		// TODO Auto-generated method stub
		return businessRepository.findAll();
	}
    @Override
	public Business getBusiness(int id) {
		// TODO Auto-generated method stub
		Business pdt = new Business();
		Optional<Business> optionalBusiness = businessRepository.findById(id);
		if (optionalBusiness.isPresent())
			pdt = optionalBusiness.get();
		return pdt;
	}

	@Override
	public void addBusiness(Business business) {
		// TODO Auto-generated method stub
		businessRepository.save(business);

	}

	@Override
	public void editBusiness(int id, Business business) {
		// TODO Auto-generated method stub
		businessRepository.save(business);
	}

	@Override
	public void deleteBusiness(int id) {
		// TODO Auto-generated method stub
		businessRepository.deleteById(id);
	}

}
