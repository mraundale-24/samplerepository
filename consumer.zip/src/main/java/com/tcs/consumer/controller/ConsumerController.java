package com.tcs.consumer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.consumer.entity.Consumer;
import com.tcs.consumer.service.ConsumerService;
@RestController
public class ConsumerController {

	@Autowired
	ConsumerService consumerService;
	
	@GetMapping("/")
	public List<Consumer> getConsumer() {
		return consumerService.getConsumer();
	}

	@GetMapping("/{id}")
	public Consumer getConsumerById(@PathVariable int id) {
		return consumerService.getConsumer(id);
	}

	@PostMapping("/")
	public void addConsumer(@RequestBody Consumer consumer){
		consumerService.addConsumer(consumer);
	}
	
	@DeleteMapping("/{id}")
	public void deleteConsumer(@PathVariable int id) {
		consumerService.deleteConsumer(id);
	}
	
}
