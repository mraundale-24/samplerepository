package com.tcs.consumer.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



import lombok.Data;

@Entity
@Table(name = "property")
@Data
public class Property {
	
	@Id
	private int id;
	private float buildingSize;
	private String buildingType;
	private String buildingStoryes;
	private String BuildingAge;

}
