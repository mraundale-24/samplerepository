package com.tcs.consumer.controller;

//package com.tcs.business.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.consumer.entity.Business;
import com.tcs.consumer.service.BusinessService;

@RestController
@RequestMapping("/api/v1/business")
public class BusinessController {

	@Autowired
	BusinessService businessService;

	@GetMapping("/")
	public List<Business> getBusiness() {
		List<Business> business = (List<Business>) businessService.getBusiness(0);
		return business;
	}

	@GetMapping("/{id}")
	public Business getBusinessById(@PathVariable int id) {
		return businessService.getBusiness(id);
	}

	@PostMapping("/")
	public void addBusiness(@RequestBody Business business) {
		businessService.addBusiness(business);
	}
	
	@PutMapping("/{id}")
	public void editBusiness(@PathVariable int id, @RequestBody Business business) {
		businessService.editBusiness(id, business);
	}
	
	@DeleteMapping("/{id}")
	public void deleteBusiness(@PathVariable int id) {
		businessService.deleteBusiness(id);
	}
}