package com.tcs.consumer.service;

import java.util.List;

import com.tcs.consumer.entity.Business;

public interface BusinessService {

	public List<Business> getBusiness();

	public Business getBusiness(int id);

	public void addBusiness(Business business);

	public void editBusiness(int id, Business business);

	public void deleteBusiness(int id);

}