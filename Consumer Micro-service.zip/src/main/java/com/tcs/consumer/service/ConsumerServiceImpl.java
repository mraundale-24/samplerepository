package com.tcs.consumer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.tcs.consumer.entity.Consumer;
import com.tcs.consumer.repo.ConsumerRepository;

 public class ConsumerServiceImpl implements ConsumerService {
    @Autowired
    ConsumerRepository consumerRepository;
	@Override
	public List<Consumer> getConsumer() {
		// TODO Auto-generated method stub
		return consumerRepository.findAll();
	}

	@Override
	public Consumer getConsumer(int id) {
		// TODO Auto-generated method stub
		Consumer pdt = new Consumer();
		Optional<Consumer> optionalConsumer = consumerRepository.findById(id);
		if (optionalConsumer.isPresent())
			pdt = optionalConsumer.get();
		return pdt;
	}

	@Override
	public void addConsumer(Consumer consumer) {
		// TODO Auto-generated method stub
		consumerRepository.save(consumer);
	}

	@Override
	public void editConsumer(int id, Consumer consumer) {
		// TODO Auto-generated method stub
		consumerRepository.save(consumer);
	}

	@Override
	public void deleteConsumer(int id) {
		// TODO Auto-generated method stub
		consumerRepository.deleteById(id);
	}

	@Override
	public void addProduct(Consumer consumer) {
		// TODO Auto-generated method stub
		
	}

	

}

