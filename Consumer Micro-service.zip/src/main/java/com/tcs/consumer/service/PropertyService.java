package com.tcs.consumer.service;


import java.util.List;

import com.tcs.consumer.entity.Property;

public interface PropertyService {

	public List<Property> getProperty();

	public Property getPropertyById(int id);

	public void addProperty(Property property);

	public void editPropertyr(int id, Property property);

	public void deleteProperty(int id);
	
}

