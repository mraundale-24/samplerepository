//for creating consumer

CREATE TABLE CONSUMER(id int,name varchar,validityperiod_of_consumer int,businessoverview varchar,agent_details varchar);

INSERT INTO `tcs1`.`consumer` (`id`,`name`,`validityperiod_of_consumer`,`businessoverview`,'agent_details') VALUES (101,'ABC',2,'Management','MarketingAgent');
INSERT INTO `tcs1`.`consumer` (`id`,`name`,`validityperiod_of_consumer`,`businessoverview`,'agent_details') VALUES (102,'XYZ',5,'Ownership','MarketingAgent');
INSERT INTO `tcs1`.`consumer` (`id`,`name`,`validityperiod_of_consumer`,`businessoverview`,'agent_details') VALUES (103,'MNP',6,'CUSTOMER','Agent');
INSERT INTO `tcs1`.`consumer` (`id`,`name',`validityperiod_of_consumer`,`businessoverview`,'agent_details') VALUES (104,'STR',4,'Transport','ContractorAgent');
INSERT INTO `tcs1`.`consumer` (`id`,`name`,`validityperiod_of_consumer`,`businessoverview,`'agent_details') VALUES (105,'PQR',3,'ElevatorPitch','PrivateAgent');

//for Business

CREATE TABLE BUSINESS(id int,annual_turnover int,business_type varchar,total_employees int);

INSERT INTO `tcs1`.`business` (`id`, `annual_turnover`, `business_type`, `total_employees`) VALUES ('1', '500000', 'private', '70000');
INSERT INTO `tcs1`.`business` (`id`, `annual_turnover`, `business_type`, `total_employees`) VALUES ('2', '600020', 'public', '45000');
INSERT INTO `tcs1`.`business` (`id`, `annual_turnover`, `business_type`, `total_employees`) VALUES ('3', '45000', 'private', '10000');
INSERT INTO `tcs1`.`business` (`id`, `annual_turnover`, `business_type`, `total_employees`) VALUES ('4', '8000', 'Govt+private', '65000');
INSERT INTO `tcs1`.`business` (`id`, `annual_turnover`, `business_type`, `total_employees`) VALUES ('5', '98000', 'govt', '65300');


//for property

CREATE TABLE PROPERTY(id int,building_age varchar,building_size float,building_storyes varchar,building_type varchar);

INSERT INTO `property` (`id`,`building_age`,`building_size`,`building_storyes`,'building_type') VALUES (101,'Thirty',154.2,'Sole','sale');
INSERT INTO `property` (`id`,`building_age`,`building_size`,`building_storyes`,'building_type') VALUES (102,'Fifty',542.0,'Partnerships','Auto');
INSERT INTO `property` (`id`,`building_age`,`building_size`,`building_storyes`,'building_type') VALUES (103,'Ten',621.3,'vCorporation','private');
INSERT INTO `property` (`id`,`building_age',`building_size`,`building_storyes`,'building_type') VALUES (104,'Twenty',448.5,'Transport','Govt');
INSERT INTO `property` (`id`,`building_age`,`building_size`,`building_storyes,`'building_type') VALUES (105,'eleven',385.8,'Apartmentpart','Govt+private');






