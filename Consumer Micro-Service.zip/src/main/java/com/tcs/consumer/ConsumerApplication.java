package com.tcs.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;




@SpringBootApplication(scanBasePackages = {
        "com.example.demo"
})
@EnableEurekaClient

//@OpenAPIDefinition(info = @Info(title = "Sample API", version = "1.0", description = "Sample API"))
public class ConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumerApplication.class, args);
	}


}
