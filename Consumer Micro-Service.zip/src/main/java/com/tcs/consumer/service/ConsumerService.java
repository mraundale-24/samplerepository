package com.tcs.consumer.service;

import java.util.List;

import com.tcs.consumer.entity.Consumer;

public interface ConsumerService {
	public List<Consumer> getConsumer();

	public Consumer getConsumer(int id);

	public void addProduct(Consumer consumer);

	public void editConsumer(int id, Consumer consumer);

	public void deleteConsumer(int id);

	public void addConsumer(Consumer consumer);

}
