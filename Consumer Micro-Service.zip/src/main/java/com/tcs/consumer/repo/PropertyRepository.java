package com.tcs.consumer.repo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.consumer.entity.Property;


@Repository
public interface PropertyRepository extends JpaRepository<Property, Integer>{

}
